import React from "react";
import { StatusBar } from "expo-status-bar";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { View, Text, StyleSheet } from "react-native";

import { AppStateProvider, useAppState } from "./src/AppState";
import { COLORS } from "./src/theme";

import HomeScreen from "./src/screens/HomeScreen";
import PricesScreen from "./src/screens/PricesScreen";
import CropDetailScreen from "./src/screens/CropDetailScreen";
import SellScreen from "./src/screens/SellScreen";
import MarketScreen from "./src/screens/MarketScreen";
import CartScreen from "./src/screens/CartScreen";

const Tab = createBottomTabNavigator();
const PricesStack = createNativeStackNavigator();
const MarketStack = createNativeStackNavigator();

function PricesStackScreen() {
  return (
    <PricesStack.Navigator screenOptions={{ headerStyle: { backgroundColor: COLORS.paper }, headerTintColor: COLORS.leafDeep }}>
      <PricesStack.Screen name="PriceBoard" component={PricesScreen} options={{ title: "Price Board" }} />
      <PricesStack.Screen name="CropDetail" component={CropDetailScreen} options={{ title: "Crop Detail" }} />
    </PricesStack.Navigator>
  );
}

function MarketStackScreen() {
  return (
    <MarketStack.Navigator screenOptions={{ headerStyle: { backgroundColor: COLORS.paper }, headerTintColor: COLORS.leafDeep }}>
      <MarketStack.Screen name="MarketList" component={MarketScreen} options={{ title: "Marketplace" }} />
      <MarketStack.Screen name="Cart" component={CartScreen} options={{ title: "Your Cart" }} />
    </MarketStack.Navigator>
  );
}

function CartTabIcon({ color, size }) {
  const { cartCount } = useAppState();
  return (
    <View>
      <Ionicons name="basket-outline" size={size} color={color} />
      {cartCount > 0 && (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{cartCount}</Text>
        </View>
      )}
    </View>
  );
}

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerStyle: { backgroundColor: COLORS.leafDeep },
        headerTintColor: COLORS.paper,
        headerTitleStyle: { fontWeight: "700" },
        tabBarActiveTintColor: COLORS.leaf,
        tabBarInactiveTintColor: COLORS.soil,
        tabBarStyle: { borderTopColor: "rgba(107,74,46,0.2)" },
        tabBarIcon: ({ color, size }) => {
          if (route.name === "Home") return <Ionicons name="home-outline" size={size} color={color} />;
          if (route.name === "Prices") return <Ionicons name="trending-up-outline" size={size} color={color} />;
          if (route.name === "Sell") return <Ionicons name="leaf-outline" size={size} color={color} />;
          if (route.name === "Market") return <CartTabIcon color={color} size={size} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: "MandiSetu" }} />
      <Tab.Screen name="Prices" component={PricesStackScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Sell" component={SellScreen} options={{ title: "Sell Produce" }} />
      <Tab.Screen name="Market" component={MarketStackScreen} options={{ headerShown: false }} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <AppStateProvider>
      <NavigationContainer>
        <StatusBar style="dark" />
        <Tabs />
      </NavigationContainer>
    </AppStateProvider>
  );
}

const styles = StyleSheet.create({
  badge: {
    position: "absolute",
    top: -4,
    right: -8,
    backgroundColor: COLORS.marigold,
    borderRadius: 8,
    width: 16,
    height: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeText: { color: COLORS.leafDeep, fontSize: 9, fontWeight: "700" },
});
