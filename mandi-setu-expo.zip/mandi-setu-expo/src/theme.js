export const COLORS = {
  paper: "#FAF6EC",
  paperDeep: "#F1E8D3",
  leaf: "#2F5233",
  leafDeep: "#1F3A22",
  marigold: "#E2932E",
  wheat: "#C9A227",
  soil: "#6B4A2E",
  charcoal: "#241F1B",
  danger: "#B0432E",
};
