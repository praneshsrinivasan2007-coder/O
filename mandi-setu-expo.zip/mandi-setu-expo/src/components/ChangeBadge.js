import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";

export default function ChangeBadge({ change }) {
  const positive = change >= 0;
  const color = positive ? COLORS.leaf : COLORS.danger;
  return (
    <View style={styles.row}>
      <Ionicons name={positive ? "trending-up" : "trending-down"} size={13} color={color} />
      <Text style={[styles.text, { color }]}>
        {positive ? "+" : ""}
        {change}%
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 3 },
  text: { fontSize: 12, fontWeight: "700", marginLeft: 3 },
});
