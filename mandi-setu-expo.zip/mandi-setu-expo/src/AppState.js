import React, { createContext, useContext, useState } from "react";
import { seedListings } from "./data";

const AppStateContext = createContext(null);

export function AppStateProvider({ children }) {
  const [listings, setListings] = useState(seedListings);
  const [cart, setCart] = useState({});

  const addListing = (item) => setListings((l) => [item, ...l]);

  const addToCart = (item) =>
    setCart((c) => ({ ...c, [item.id]: { qty: (c[item.id]?.qty || 0) + 1 } }));

  const changeQty = (id, delta) =>
    setCart((c) => ({ ...c, [id]: { qty: Math.max(0, (c[id]?.qty || 0) + delta) } }));

  const clearCart = () => setCart({});

  const cartCount = Object.values(cart).reduce((s, v) => s + v.qty, 0);
  const cartTotal = Object.entries(cart).reduce((sum, [id, v]) => {
    const l = listings.find((x) => x.id === id);
    return sum + (l ? l.price * v.qty : 0);
  }, 0);

  return (
    <AppStateContext.Provider
      value={{ listings, addListing, cart, addToCart, changeQty, clearCart, cartCount, cartTotal }}
    >
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error("useAppState must be used inside AppStateProvider");
  return ctx;
}
