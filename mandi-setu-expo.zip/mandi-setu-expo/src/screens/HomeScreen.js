import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { COLORS } from "../theme";
import { CROPS, formatINR } from "../data";
import { useAppState } from "../AppState";
import ChangeBadge from "../components/ChangeBadge";

export default function HomeScreen({ navigation }) {
  const { listings } = useAppState();
  const topMovers = [...CROPS].sort((a, b) => Math.abs(b.change) - Math.abs(a.change)).slice(0, 3);

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <View style={styles.hero}>
        <Text style={styles.heroTitle}>Fair prices, straight from farm to buyer</Text>
        <Text style={styles.heroSub}>
          Real-time mandi prices and a direct marketplace connecting farmers with buyers.
        </Text>
        <View style={styles.heroBtnRow}>
          <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.navigate("Prices")}>
            <Text style={styles.primaryBtnText}>Check today's prices</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.secondaryBtn} onPress={() => navigation.navigate("Sell")}>
            <Text style={styles.secondaryBtnText}>Sell my produce</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.statsRow}>
        <StatCard value={CROPS.length} label="CROPS LIVE" />
        <StatCard value={listings.length} label="LISTINGS" />
        <StatCard value="0%" label="MIDDLEMAN" />
      </View>

      <Text style={styles.sectionLabel}>What Mandi Setu does</Text>
      <FeatureRow emoji="📈" title="Live Price Board" desc="Daily wholesale mandi rates and trends." onPress={() => navigation.navigate("Prices")} />
      <FeatureRow emoji="🧺" title="Sell Your Produce" desc="Post quantity, price and location — buyers find you." onPress={() => navigation.navigate("Sell")} />
      <FeatureRow emoji="🤝" title="Buyer Marketplace" desc="Browse farmer listings, connect directly." onPress={() => navigation.navigate("Market")} />

      <View style={styles.topRow}>
        <Text style={styles.sectionLabel}>Today's top prices</Text>
        <TouchableOpacity onPress={() => navigation.navigate("Prices")}>
          <Text style={styles.viewAll}>View all</Text>
        </TouchableOpacity>
      </View>
      {topMovers.map((c) => (
        <TouchableOpacity
          key={c.id}
          style={styles.priceRow}
          onPress={() => navigation.navigate("Prices", { screen: "CropDetail", params: { cropId: c.id } })}
        >
          <Text style={styles.emoji}>{c.emoji}</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.cropName}>{c.name}</Text>
            <Text style={styles.cropPrice}>{formatINR(c.price)} / quintal</Text>
          </View>
          <ChangeBadge change={c.change} />
        </TouchableOpacity>
      ))}

      <Text style={styles.footer}>
        Mandi Setu — a prototype for stronger market linkages and transparent price discovery.
      </Text>
    </ScrollView>
  );
}

function StatCard({ value, label }) {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function FeatureRow({ emoji, title, desc, onPress }) {
  return (
    <TouchableOpacity style={styles.featureRow} onPress={onPress}>
      <Text style={styles.featureEmoji}>{emoji}</Text>
      <View style={{ flex: 1 }}>
        <Text style={styles.featureTitle}>{title}</Text>
        <Text style={styles.featureDesc}>{desc}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper },
  hero: { backgroundColor: COLORS.leafDeep, borderRadius: 10, padding: 18, marginBottom: 16 },
  heroTitle: { fontSize: 22, fontWeight: "700", color: COLORS.paper, lineHeight: 28 },
  heroSub: { fontSize: 13, color: "rgba(250,246,236,0.8)", marginTop: 8, lineHeight: 19 },
  heroBtnRow: { flexDirection: "row", gap: 8, marginTop: 14 },
  primaryBtn: { flex: 1, backgroundColor: COLORS.marigold, borderRadius: 6, paddingVertical: 10, alignItems: "center" },
  primaryBtnText: { color: COLORS.leafDeep, fontSize: 12.5, fontWeight: "700" },
  secondaryBtn: { flex: 1, borderColor: "rgba(250,246,236,0.4)", borderWidth: 1.5, borderRadius: 6, paddingVertical: 10, alignItems: "center" },
  secondaryBtnText: { color: COLORS.paper, fontSize: 12.5, fontWeight: "700" },
  statsRow: { flexDirection: "row", gap: 8, marginBottom: 22 },
  statCard: { flex: 1, backgroundColor: COLORS.paperDeep, borderRadius: 8, paddingVertical: 12, alignItems: "center" },
  statValue: { fontSize: 20, fontWeight: "700", color: COLORS.leafDeep },
  statLabel: { fontSize: 10, color: COLORS.soil, marginTop: 2 },
  sectionLabel: { fontSize: 13, fontWeight: "700", color: COLORS.soil, marginBottom: 10 },
  featureRow: { flexDirection: "row", gap: 12, borderWidth: 1.5, borderColor: "rgba(107,74,46,0.17)", borderRadius: 8, padding: 12, marginBottom: 8, alignItems: "flex-start" },
  featureEmoji: { fontSize: 20 },
  featureTitle: { fontSize: 14, fontWeight: "700", color: COLORS.charcoal },
  featureDesc: { fontSize: 12, color: COLORS.soil, marginTop: 2 },
  topRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", marginTop: 14, marginBottom: 8 },
  viewAll: { color: COLORS.leaf, fontSize: 12.5, fontWeight: "600" },
  priceRow: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1.5, borderColor: "rgba(107,74,46,0.17)", borderRadius: 8, padding: 10, marginBottom: 6 },
  emoji: { fontSize: 20 },
  cropName: { fontSize: 13.5, fontWeight: "600", color: COLORS.charcoal },
  cropPrice: { fontSize: 11.5, color: COLORS.soil },
  footer: { textAlign: "center", fontSize: 11, color: "rgba(107,74,46,0.6)", marginTop: 24 },
});
