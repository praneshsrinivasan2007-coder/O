import React from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { COLORS } from "../theme";
import { CROPS, formatINR } from "../data";
import ChangeBadge from "../components/ChangeBadge";

export default function PricesScreen({ navigation }) {
  return (
    <View style={styles.screen}>
      <Text style={styles.subtitle}>Tap any crop to see full details and mandi listings.</Text>
      <FlatList
        data={CROPS}
        keyExtractor={(c) => c.id}
        contentContainerStyle={{ padding: 16, paddingTop: 4 }}
        renderItem={({ item: c }) => (
          <TouchableOpacity style={styles.row} onPress={() => navigation.navigate("CropDetail", { cropId: c.id })}>
            <Text style={styles.emoji}>{c.emoji}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{c.name}</Text>
              <Text style={styles.price}>{formatINR(c.price)} / quintal</Text>
            </View>
            <ChangeBadge change={c.change} />
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper },
  subtitle: { fontSize: 12.5, color: COLORS.soil, paddingHorizontal: 16, paddingTop: 14 },
  row: { flexDirection: "row", alignItems: "center", gap: 12, borderWidth: 1.5, borderColor: "rgba(107,74,46,0.17)", borderRadius: 8, padding: 12, marginBottom: 8 },
  emoji: { fontSize: 24 },
  name: { fontSize: 14, fontWeight: "600", color: COLORS.charcoal },
  price: { fontSize: 12, color: COLORS.soil },
});
