import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { cropById, formatINR } from "../data";
import { useAppState } from "../AppState";

export default function MarketScreen({ navigation }) {
  const { listings, cart, addToCart, cartCount, cartTotal } = useAppState();
  const [query, setQuery] = useState("");

  const filtered = listings.filter((l) => {
    const crop = cropById(l.crop);
    const q = query.toLowerCase();
    return crop.name.toLowerCase().includes(q) || l.farmer.toLowerCase().includes(q) || l.village.toLowerCase().includes(q);
  });

  return (
    <View style={styles.screen}>
      <Text style={styles.subtitle}>Produce available directly from farmers right now.</Text>
      <View style={styles.searchBar}>
        <Ionicons name="search" size={16} color={COLORS.soil} />
        <TextInput
          style={styles.searchInput}
          value={query}
          onChangeText={setQuery}
          placeholder="Search crop, farmer or village"
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(l) => l.id}
        contentContainerStyle={{ padding: 16, paddingTop: 0, paddingBottom: cartCount > 0 ? 90 : 20 }}
        renderItem={({ item: l }) => {
          const crop = cropById(l.crop);
          const cartQty = cart[l.id]?.qty || 0;
          return (
            <View style={styles.card}>
              <View style={styles.cardTop}>
                <View style={{ flexDirection: "row", gap: 10 }}>
                  <Text style={styles.cardEmoji}>{crop.emoji}</Text>
                  <View>
                    <Text style={styles.cardCrop}>{crop.name}</Text>
                    <Text style={styles.cardFarmer}>{l.farmer} · {l.village}</Text>
                  </View>
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={styles.cardPrice}>{formatINR(l.price)}</Text>
                  <Text style={styles.cardUnit}>/ quintal</Text>
                </View>
              </View>
              <Text style={styles.cardNote}>{l.qty} quintals · {l.note}</Text>
              <View style={styles.cardBottom}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
                  <Ionicons name="call-outline" size={12} color={COLORS.soil} />
                  <Text style={styles.phone}>{l.phone}</Text>
                </View>
                <TouchableOpacity
                  style={[styles.buyBtn, cartQty > 0 && styles.buyBtnActive]}
                  onPress={() => addToCart(l)}
                >
                  <Text style={[styles.buyBtnText, cartQty > 0 && styles.buyBtnTextActive]}>
                    {cartQty > 0 ? `In cart (${cartQty})` : "Buy"}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
        ListEmptyComponent={<Text style={styles.empty}>No listings match that search.</Text>}
      />

      {cartCount > 0 && (
        <TouchableOpacity style={styles.cartBar} onPress={() => navigation.navigate("Cart")}>
          <Text style={styles.cartBarText}>View cart ({cartCount})</Text>
          <Text style={styles.cartBarText}>{formatINR(cartTotal)}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper },
  subtitle: { fontSize: 12.5, color: COLORS.soil, paddingHorizontal: 16, paddingTop: 14 },
  searchBar: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: COLORS.paperDeep, borderWidth: 1.5, borderColor: "rgba(107,74,46,0.2)", borderRadius: 6, margin: 16, marginBottom: 8, paddingHorizontal: 12, paddingVertical: 8 },
  searchInput: { flex: 1, fontSize: 14, color: COLORS.charcoal },
  card: { borderWidth: 1.5, borderColor: "rgba(107,74,46,0.17)", borderRadius: 8, padding: 13, marginBottom: 10, backgroundColor: COLORS.paper },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  cardEmoji: { fontSize: 26 },
  cardCrop: { fontSize: 14.5, fontWeight: "700", color: COLORS.charcoal },
  cardFarmer: { fontSize: 11.5, color: COLORS.soil, marginTop: 2 },
  cardPrice: { fontSize: 15, fontWeight: "700", color: COLORS.leafDeep },
  cardUnit: { fontSize: 10.5, color: COLORS.soil },
  cardNote: { fontSize: 12, color: COLORS.charcoal, opacity: 0.8, marginVertical: 8 },
  cardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  phone: { fontSize: 11.5, color: COLORS.soil },
  buyBtn: { borderWidth: 1.5, borderColor: COLORS.leaf, borderRadius: 5, paddingVertical: 6, paddingHorizontal: 11 },
  buyBtnActive: { backgroundColor: COLORS.leaf },
  buyBtnText: { fontSize: 12.5, fontWeight: "700", color: COLORS.leaf },
  buyBtnTextActive: { color: COLORS.paper },
  empty: { textAlign: "center", padding: 30, color: COLORS.soil, fontSize: 13 },
  cartBar: { position: "absolute", bottom: 16, left: 16, right: 16, backgroundColor: COLORS.leafDeep, borderRadius: 8, paddingVertical: 12, paddingHorizontal: 16, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  cartBarText: { color: COLORS.paper, fontSize: 13.5, fontWeight: "700" },
});
