import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { COLORS } from "../theme";
import { cropById, formatINR } from "../data";
import { useAppState } from "../AppState";
import ChangeBadge from "../components/ChangeBadge";

export default function CropDetailScreen({ route }) {
  const { cropId } = route.params;
  const crop = cropById(cropId);
  const { listings } = useAppState();
  const cropListings = listings.filter((l) => l.crop === cropId);

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.headerRow}>
        <Text style={styles.emoji}>{crop.emoji}</Text>
        <View>
          <Text style={styles.name}>{crop.name}</Text>
          <Text style={styles.price}>{formatINR(crop.price)} / quintal</Text>
        </View>
      </View>

      <View style={styles.trendCard}>
        <Text style={styles.trendLabel}>Price trend</Text>
        <ChangeBadge change={crop.change} />
      </View>

      <Text style={styles.sectionLabel}>Available from farmers</Text>
      {cropListings.length === 0 ? (
        <Text style={styles.empty}>No farmer listings for this crop right now.</Text>
      ) : (
        cropListings.map((l) => (
          <View key={l.id} style={styles.listingRow}>
            <View style={styles.listingTop}>
              <View>
                <Text style={styles.farmer}>{l.farmer}</Text>
                <Text style={styles.village}>{l.village}</Text>
              </View>
              <Text style={styles.listingPrice}>{formatINR(l.price)}</Text>
            </View>
            <Text style={styles.note}>{l.qty} quintals available · {l.note}</Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper },
  headerRow: { flexDirection: "row", gap: 12, alignItems: "center", marginBottom: 14 },
  emoji: { fontSize: 38 },
  name: { fontSize: 19, fontWeight: "700", color: COLORS.charcoal },
  price: { fontSize: 13, color: COLORS.soil },
  trendCard: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: COLORS.paperDeep, borderRadius: 8, padding: 14, marginBottom: 18 },
  trendLabel: { fontSize: 11, color: COLORS.soil, marginBottom: 4 },
  sectionLabel: { fontSize: 12.5, fontWeight: "700", color: COLORS.soil, marginBottom: 8 },
  empty: { fontSize: 13, color: COLORS.soil, opacity: 0.75 },
  listingRow: { borderWidth: 1.5, borderColor: "rgba(107,74,46,0.17)", borderRadius: 8, padding: 12, marginBottom: 8 },
  listingTop: { flexDirection: "row", justifyContent: "space-between" },
  farmer: { fontSize: 13.5, fontWeight: "700", color: COLORS.charcoal },
  village: { fontSize: 11.5, color: COLORS.soil, marginTop: 2 },
  listingPrice: { fontSize: 15, fontWeight: "700", color: COLORS.leafDeep },
  note: { fontSize: 12, color: COLORS.charcoal, opacity: 0.8, marginTop: 6 },
});
