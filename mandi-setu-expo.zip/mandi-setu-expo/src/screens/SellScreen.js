import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, ScrollView, TouchableOpacity, Platform } from "react-native";
import { Picker } from "@react-native-picker/picker";
import { COLORS } from "../theme";
import { CROPS } from "../data";
import { useAppState } from "../AppState";

export default function SellScreen({ navigation }) {
  const { addListing } = useAppState();
  const [form, setForm] = useState({ crop: "", qty: "", price: "", village: "", phone: "", note: "" });
  const [posted, setPosted] = useState(false);

  const update = (field) => (value) => setForm((f) => ({ ...f, [field]: value }));
  const canPost = form.crop && form.qty && form.price && form.village && form.phone;

  const handlePost = () => {
    if (!canPost) return;
    addListing({
      id: `l${Date.now()}`,
      crop: form.crop,
      farmer: "You",
      village: form.village,
      phone: form.phone,
      qty: parseFloat(form.qty) || 0,
      price: parseFloat(form.price) || 0,
      note: form.note.trim() || "Fresh produce, ready now.",
    });
    setForm({ crop: "", qty: "", price: "", village: "", phone: "", note: "" });
    setPosted(true);
    setTimeout(() => {
      setPosted(false);
      navigation.navigate("Market");
    }, 1400);
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.subtitle}>Buyers browsing the marketplace will see your listing right away.</Text>

      {posted && (
        <View style={styles.toast}>
          <Text style={styles.toastText}>🎉 Listing posted — buyers can now find it in the marketplace.</Text>
        </View>
      )}

      <Text style={styles.label}>Crop</Text>
      <View style={styles.pickerWrap}>
        <Picker selectedValue={form.crop} onValueChange={update("crop")}>
          <Picker.Item label="Select crop" value="" />
          {CROPS.map((c) => (
            <Picker.Item key={c.id} label={`${c.emoji} ${c.name}`} value={c.id} />
          ))}
        </Picker>
      </View>

      <View style={styles.row}>
        <View style={{ flex: 1 }}>
          <Text style={styles.label}>Quantity (quintals)</Text>
          <TextInput style={styles.input} keyboardType="numeric" value={form.qty} onChangeText={update("qty")} placeholder="e.g. 30" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.label}>Price (₹ / quintal)</Text>
          <TextInput style={styles.input} keyboardType="numeric" value={form.price} onChangeText={update("price")} placeholder="e.g. 1500" />
        </View>
      </View>

      <Text style={styles.label}>Your village / mandi area</Text>
      <TextInput style={styles.input} value={form.village} onChangeText={update("village")} placeholder="e.g. Nashik, MH" />

      <Text style={styles.label}>Contact number</Text>
      <TextInput style={styles.input} keyboardType="phone-pad" value={form.phone} onChangeText={update("phone")} placeholder="10-digit mobile number" />

      <Text style={styles.label}>Note for buyers (optional)</Text>
      <TextInput
        style={[styles.input, { height: 80, textAlignVertical: "top" }]}
        multiline
        value={form.note}
        onChangeText={update("note")}
        placeholder="Quality, transport, pickup details..."
      />

      <TouchableOpacity style={[styles.postBtn, !canPost && styles.postBtnDisabled]} disabled={!canPost} onPress={handlePost}>
        <Text style={styles.postBtnText}>Post listing</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper },
  subtitle: { fontSize: 12.5, color: COLORS.soil, marginBottom: 14 },
  toast: { backgroundColor: "rgba(47,82,51,0.09)", borderColor: "rgba(47,82,51,0.35)", borderWidth: 1.5, borderRadius: 8, padding: 12, marginBottom: 14 },
  toastText: { color: COLORS.leafDeep, fontSize: 13 },
  label: { fontSize: 12, fontWeight: "600", color: COLORS.soil, marginBottom: 5, marginTop: 12 },
  input: { borderWidth: 1.5, borderColor: "rgba(107,74,46,0.2)", borderRadius: 6, padding: 10, fontSize: 14, color: COLORS.charcoal, backgroundColor: COLORS.paper },
  pickerWrap: { borderWidth: 1.5, borderColor: "rgba(107,74,46,0.2)", borderRadius: 6, overflow: "hidden" },
  row: { flexDirection: "row", gap: 10 },
  postBtn: { backgroundColor: COLORS.leaf, borderRadius: 6, paddingVertical: 13, alignItems: "center", marginTop: 20 },
  postBtnDisabled: { backgroundColor: "rgba(47,82,51,0.35)" },
  postBtnText: { color: COLORS.paper, fontSize: 14, fontWeight: "700" },
});
