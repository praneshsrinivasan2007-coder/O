import React, { useState } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { cropById, formatINR } from "../data";
import { useAppState } from "../AppState";

export default function CartScreen({ navigation }) {
  const { cart, listings, changeQty, clearCart, cartTotal } = useAppState();
  const [checkedOut, setCheckedOut] = useState(false);

  const items = Object.entries(cart)
    .map(([id, v]) => ({ ...listings.find((l) => l.id === id), qty: v.qty }))
    .filter((i) => i.qty > 0 && i.id);

  const handleCheckout = () => {
    setCheckedOut(true);
    setTimeout(() => {
      clearCart();
      setCheckedOut(false);
      navigation.navigate("Market");
    }, 1800);
  };

  if (checkedOut) {
    return (
      <View style={styles.doneScreen}>
        <View style={styles.doneCircle}>
          <Ionicons name="checkmark" size={26} color={COLORS.paper} />
        </View>
        <Text style={styles.doneTitle}>Request sent to farmers</Text>
        <Text style={styles.doneSub}>They'll confirm quantity and pickup by phone.</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <FlatList
        data={items}
        keyExtractor={(i) => i.id}
        contentContainerStyle={{ padding: 16 }}
        ListEmptyComponent={<Text style={styles.empty}>Nothing here yet — add produce from the Marketplace.</Text>}
        renderItem={({ item }) => {
          const crop = cropById(item.crop);
          return (
            <View style={styles.row}>
              <Text style={styles.emoji}>{crop.emoji}</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{crop.name}</Text>
                <Text style={styles.sub}>{item.farmer} · {item.village}</Text>
              </View>
              <View style={styles.qtyRow}>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(item.id, -1)}>
                  <Ionicons name="remove" size={12} color={COLORS.soil} />
                </TouchableOpacity>
                <Text style={styles.qtyText}>{item.qty}</Text>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(item.id, 1)}>
                  <Ionicons name="add" size={12} color={COLORS.soil} />
                </TouchableOpacity>
              </View>
              <Text style={styles.lineTotal}>{formatINR(item.price * item.qty)}</Text>
            </View>
          );
        }}
        ListFooterComponent={
          items.length > 0 ? (
            <>
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>{formatINR(cartTotal)}</Text>
              </View>
              <TouchableOpacity style={styles.checkoutBtn} onPress={handleCheckout}>
                <Text style={styles.checkoutBtnText}>Send request to farmers</Text>
              </TouchableOpacity>
            </>
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper },
  empty: { textAlign: "center", padding: 30, color: COLORS.soil, fontSize: 13.5 },
  row: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1.5, borderColor: "rgba(107,74,46,0.17)", borderRadius: 8, padding: 12, marginBottom: 10 },
  emoji: { fontSize: 22 },
  name: { fontSize: 13.5, fontWeight: "700", color: COLORS.charcoal },
  sub: { fontSize: 11, color: COLORS.soil },
  qtyRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  qtyBtn: { width: 22, height: 22, borderRadius: 4, borderWidth: 1.5, borderColor: "rgba(107,74,46,0.35)", alignItems: "center", justifyContent: "center" },
  qtyText: { fontSize: 13, minWidth: 14, textAlign: "center" },
  lineTotal: { fontSize: 13, fontWeight: "700", color: COLORS.leafDeep, minWidth: 64, textAlign: "right" },
  totalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 14, borderTopWidth: 1.5, borderTopColor: "rgba(107,74,46,0.2)", marginTop: 6 },
  totalLabel: { fontSize: 14, fontWeight: "700", color: COLORS.charcoal },
  totalValue: { fontSize: 18, fontWeight: "700", color: COLORS.leafDeep },
  checkoutBtn: { backgroundColor: COLORS.leaf, borderRadius: 6, paddingVertical: 13, alignItems: "center", marginTop: 14 },
  checkoutBtnText: { color: COLORS.paper, fontSize: 14, fontWeight: "700" },
  doneScreen: { flex: 1, backgroundColor: COLORS.paper, alignItems: "center", justifyContent: "center", padding: 24 },
  doneCircle: { width: 56, height: 56, borderRadius: 28, backgroundColor: COLORS.leaf, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  doneTitle: { fontSize: 19, fontWeight: "700", color: COLORS.leafDeep },
  doneSub: { fontSize: 13, color: COLORS.soil, marginTop: 6, textAlign: "center" },
});
