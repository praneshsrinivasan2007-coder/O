export const CROPS = [
  { id: "wheat", name: "Wheat", emoji: "🌾", price: 2125, change: 1.8 },
  { id: "paddy", name: "Paddy (Rice)", emoji: "🌱", price: 2040, change: -0.6 },
  { id: "onion", name: "Onion", emoji: "🧅", price: 1450, change: 4.2 },
  { id: "potato", name: "Potato", emoji: "🥔", price: 980, change: -2.1 },
  { id: "tomato", name: "Tomato", emoji: "🍅", price: 1620, change: 6.5 },
  { id: "cotton", name: "Cotton", emoji: "☁️", price: 6800, change: 0.4 },
  { id: "soybean", name: "Soybean", emoji: "🫘", price: 4350, change: -1.2 },
  { id: "maize", name: "Maize", emoji: "🌽", price: 2015, change: 0.9 },
];

export const seedListings = [
  {
    id: "l1",
    crop: "onion",
    farmer: "Ramesh Patil",
    village: "Nashik, MH",
    phone: "98xxxxxx21",
    qty: 40,
    price: 1400,
    note: "Fresh harvest, can arrange transport.",
  },
  {
    id: "l2",
    crop: "wheat",
    farmer: "Sita Devi",
    village: "Malwa, MP",
    phone: "97xxxxxx08",
    qty: 60,
    price: 2100,
    note: "Good quality, moisture tested.",
  },
  {
    id: "l3",
    crop: "tomato",
    farmer: "Arjun Yadav",
    village: "Nagpur, MH",
    phone: "99xxxxxx73",
    qty: 25,
    price: 1550,
    note: "Ready for pickup this week.",
  },
];

export function cropById(id) {
  return CROPS.find((c) => c.id === id);
}

export function formatINR(n) {
  return "₹" + Number(n).toLocaleString("en-IN");
}
